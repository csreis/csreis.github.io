f = document.createElement("iframe");
f.src = chrome.runtime.getURL("frame.html");
document.body.appendChild(f);
