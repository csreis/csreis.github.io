function navFrame(url) {
  document.getElementById("frame1").src = url;
}

function showTopSites() {
  chrome.topSites.get(function(data) {
    var sites = "Top sites:\n";
    data.map(function(topSite) {
      sites += topSite.title + "\n";
    });
    alert(sites);
  });
}

document.addEventListener("DOMContentLoaded", function () {
  document.getElementById("showTopSites").onclick = showTopSites;

  document.getElementById("navFrameComplex").onclick = function () { navFrame("https://build.chromium.org"); };
  document.getElementById("navFrameSimple").onclick = function () { navFrame("http://csreis.github.io/tests"); };
  document.getElementById("navFrameForm").onclick = function () { navFrame("form-post.html"); };
  document.getElementById("navFrameYoutube").onclick = function () { navFrame("https://www.youtube.com/embed/lm-Vnx58UYo?autoplay=0&start=48&origin=chrome-extension://" + chrome.runtime.id); };
});
